const textConstructorDescJson = {
  "head" : {
    "title" : "конструктор текстов",
    "body"  : {
      "text" : {
        "title": "начальный текст в конструкторе",
      },
      "objects" : {
        "title": ""
      },
      "styles" : {
        "title": ""
      },
      "markStyle" : {
        "title": ""
      },
      "basement" : {
        "title": ""
      },
      "audioMap" : {
        "title": ""
      },
      "randomMixWord" : {
        "title": ""
      },
      "randomDelWord" : {
        "title": ""
      },
      "randomView" : {
        "title": ""
      },
      "notDelFromBasement" : {
        "title": ""
      },
      "canMoveWord" : {
        "title": ""
      },
      "noCursor" : {
        "title": ""
      },
      "focusAsCursor" : {
        "title": ""
      },
      "answerList" : {
        "title": ""
      },
      "fontSize" : {
        "title": ""
      },
      "boxHeight" : {
        "title": ""
      },
      "btnKeyboard" : {
        "title": ""
      },
      "btnUndo" : {
        "title": ""
      },
      "btnRedo" : {
        "title": ""
      },
      "btnBackspace" : {
        "title": ""
      },
      "btnDelete" : {
        "title": ""
      },
      "btnClear" : {
        "title": ""
      },
    }
  }
};