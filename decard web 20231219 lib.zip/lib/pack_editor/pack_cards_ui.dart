import 'package:flutter/material.dart';

class PackCardsUI extends StatefulWidget {
  const PackCardsUI({Key? key}) : super(key: key);

  @override
  State<PackCardsUI> createState() => _PackCardsUIState();
}

class _PackCardsUIState extends State<PackCardsUI> {
  @override
  Widget build(BuildContext context) {
    return const Center(child: Text('Стили'));
  }
}
