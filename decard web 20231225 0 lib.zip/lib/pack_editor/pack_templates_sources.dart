import 'package:flutter/material.dart';

class TemplatesSources extends StatelessWidget {
  const TemplatesSources({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
